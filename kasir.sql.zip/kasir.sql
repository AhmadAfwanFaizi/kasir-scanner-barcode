-- phpMyAdmin SQL Dump
-- version 4.9.5deb2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Feb 05, 2021 at 04:48 PM
-- Server version: 8.0.23-0ubuntu0.20.04.1
-- PHP Version: 7.4.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kasir`
--

-- --------------------------------------------------------

--
-- Table structure for table `kategori`
--

CREATE TABLE `kategori` (
  `id` int NOT NULL,
  `kategori` varchar(100) NOT NULL,
  `dibuat` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `diubah` datetime DEFAULT NULL,
  `dihapus` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `kategori`
--

INSERT INTO `kategori` (`id`, `kategori`, `dibuat`, `diubah`, `dihapus`) VALUES
(1, 'minuman', '2021-01-30 20:39:26', NULL, NULL),
(2, 'makanan', '2021-01-31 00:27:24', NULL, NULL),
(3, 'kecantikan', '2021-01-31 00:54:06', NULL, '2021-02-01 01:33:45'),
(4, 'kecantikan', '2021-02-02 14:48:02', NULL, '2021-02-02 01:52:51'),
(5, 'kecantikan', '2021-02-03 11:22:04', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `produk`
--

CREATE TABLE `produk` (
  `id` int NOT NULL,
  `id_user` int NOT NULL,
  `kode_produk` varchar(225) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `id_kategori` varchar(100) NOT NULL,
  `id_satuan` varchar(100) NOT NULL,
  `nama_produk` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `harga_produk` int NOT NULL,
  `stok_produk` int NOT NULL DEFAULT '0',
  `dibuat` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `diubah` datetime DEFAULT NULL,
  `dihapus` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `produk`
--

INSERT INTO `produk` (`id`, `id_user`, `kode_produk`, `id_kategori`, `id_satuan`, `nama_produk`, `harga_produk`, `stok_produk`, `dibuat`, `diubah`, `dihapus`) VALUES
(2, 1, '123', '2', '1', 'kuaci rebo matcha', 15000, 24, '2021-01-31 19:47:17', NULL, NULL),
(3, 1, '1', '2', '1', 'soyjoy', 10000, 12, '2021-02-01 13:12:46', NULL, NULL),
(4, 1, '321', '2', '1', 'nanas muda', 20000, 31, '2021-02-01 16:08:12', NULL, NULL),
(5, 1, '111', '1', '3', 'panter', 2000, 16, '2021-02-02 11:39:01', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `satuan`
--

CREATE TABLE `satuan` (
  `id` int NOT NULL,
  `satuan` varchar(100) NOT NULL,
  `dibuat` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `diubah` datetime DEFAULT NULL,
  `dihapus` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `satuan`
--

INSERT INTO `satuan` (`id`, `satuan`, `dibuat`, `diubah`, `dihapus`) VALUES
(1, 'pcsv', '2021-01-30 20:18:46', NULL, '2021-02-02 21:09:03'),
(2, 'kage', '2021-01-31 01:20:29', NULL, NULL),
(3, 'ltr', '2021-01-31 01:20:38', NULL, '2021-01-30 12:34:50');

-- --------------------------------------------------------

--
-- Table structure for table `stok`
--

CREATE TABLE `stok` (
  `id` int NOT NULL,
  `id_user` int NOT NULL,
  `kode_produk` varchar(225) NOT NULL,
  `kode_supplier` varchar(225) NOT NULL,
  `jumlah` int NOT NULL,
  `log` enum('MASUK','KELUAR') NOT NULL,
  `catatan` text,
  `dibuat` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `diubah` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `stok`
--

INSERT INTO `stok` (`id`, `id_user`, `kode_produk`, `kode_supplier`, `jumlah`, `log`, `catatan`, `dibuat`, `diubah`) VALUES
(1, 1, '123', '6014f3921aeef', 12, 'MASUK', 'none', '2021-02-04 14:19:31', NULL),
(2, 1, '1', '601522dd2e9e5', 12, 'MASUK', '', '2021-02-04 14:22:27', NULL),
(3, 1, '321', '601522fea6631', 31, 'MASUK', '', '2021-02-04 14:23:18', NULL),
(4, 1, '111', '6015232098914', 16, 'KELUAR', '', '2021-02-04 14:24:02', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `supplier`
--

CREATE TABLE `supplier` (
  `id` int NOT NULL,
  `id_user` int NOT NULL,
  `kode_supplier` varchar(225) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `nama_supplier` varchar(225) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `kontak_supplier` varchar(13) NOT NULL,
  `alamat_supplier` text NOT NULL,
  `dibuat` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `diubah` datetime DEFAULT NULL,
  `dihapus` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `supplier`
--

INSERT INTO `supplier` (`id`, `id_user`, `kode_supplier`, `nama_supplier`, `kontak_supplier`, `alamat_supplier`, `dibuat`, `diubah`, `dihapus`) VALUES
(1, 1, '6014f3921aeef', 'ahmad', '123', 'bnz', '2021-01-30 12:50:10', NULL, '2021-01-30 06:02:19'),
(2, 1, '601522dd2e9e5', 'afwan', '234', 'bnz', '2021-01-30 16:11:57', NULL, NULL),
(3, 1, '601522fea6631', 'baasri', '009', 'tipar', '2021-01-30 16:12:30', NULL, '2021-01-30 06:42:38'),
(4, 1, '6015232098914', 'faizi', '345', 'bnz', '2021-01-30 16:13:04', NULL, '2021-01-30 04:39:58'),
(5, 0, '60155177b6231', 'coba', 'coba', 'coba', '2021-01-30 19:30:47', NULL, '2021-01-30 06:41:29'),
(6, 0, '6015517f59e0c', 'coba', 'coba', 'coba', '2021-01-30 19:30:55', NULL, '2021-01-30 06:41:16'),
(7, 0, '6015547ac8db3', 'coba 3', 'q coba 3', 'q', '2021-01-30 19:43:38', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `transaksi`
--

CREATE TABLE `transaksi` (
  `id` int NOT NULL,
  `id_user` int NOT NULL,
  `kode_transaksi` varchar(225) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `kode_produk` varchar(225) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `jumlah` int NOT NULL,
  `status` enum('PENDING','FINISH') NOT NULL,
  `dibuat` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `diubah` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `dibuat` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `diubah` datetime DEFAULT NULL,
  `dihapus` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `kategori`
--
ALTER TABLE `kategori`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `produk`
--
ALTER TABLE `produk`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `satuan`
--
ALTER TABLE `satuan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `stok`
--
ALTER TABLE `stok`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `supplier`
--
ALTER TABLE `supplier`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `transaksi`
--
ALTER TABLE `transaksi`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `kategori`
--
ALTER TABLE `kategori`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `produk`
--
ALTER TABLE `produk`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `satuan`
--
ALTER TABLE `satuan`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `stok`
--
ALTER TABLE `stok`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `supplier`
--
ALTER TABLE `supplier`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `transaksi`
--
ALTER TABLE `transaksi`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
